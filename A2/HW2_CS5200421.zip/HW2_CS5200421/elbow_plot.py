import sys
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

def generate_elbow_plot(dataset_file, dimension, output_file):
    # Load dataset
    data = np.loadtxt(dataset_file)
    
    # Check if data dimension matches the given dimension
    if data.shape[1] != int(dimension):
        raise ValueError(f"Data dimension ({data.shape[1]}) doesn't match specified dimension ({dimension}).")

    # Calculate sum of squared distances for each k
    ssd = []
    for k in range(1, 16):  # k from 1 to 15
        kmeans = KMeans(n_clusters=k, random_state=42).fit(data)
        ssd.append(kmeans.inertia_)

    # Plot the elbow curve
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, 16), ssd, marker='o', linestyle='-')
    plt.title('Elbow Plot')
    plt.xlabel('Number of clusters (k)')
    plt.ylabel('Sum of squared distances')
    plt.grid(True)
    plt.savefig(output_file)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python elbow_plot.py <dataset> <dimension> <output_file>")
        sys.exit(1)

    dataset_file = sys.argv[1]
    dimension = sys.argv[2]
    output_file = sys.argv[3]
    generate_elbow_plot(dataset_file, dimension, output_file)

