#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: Q1.sh <input_file>"
    exit 1
else
    python change_format.py $1
fi
