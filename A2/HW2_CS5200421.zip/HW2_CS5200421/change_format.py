import os
import sys
import time
import matplotlib.pyplot as plt


def f(inputfileName,outputfileName,type):
    inputfile = open(inputfileName, 'r')
    outputfile = open(outputfileName, 'w')
    graph_count = 0
    vertex_count = 0
    vertex_label = {}
    while True:
        line = inputfile.readline()
        line = line.strip()
        if not line: break
        outputfile.write('t # '+str(graph_count)+'\n')
        graph_count += 1

        vertices_count = inputfile.readline()
        vertices_count = int(vertices_count.strip())
        for i in range(vertices_count):
            line = inputfile.readline()
            line = line.strip()
            try:
                label = vertex_label[line]
            except:
                vertex_label[line] = vertex_count
                vertex_count += 1
                label = vertex_label[line]
            
            outputfile.write('v '+str(i)+' '+ str(label)+'\n')

        edge_count = inputfile.readline()
        edge_count = int(edge_count.strip())
        for i in range(edge_count):
            line = inputfile.readline()
            line = line.strip()
            if type==1:
                outputfile.write('e '+line+'\n')
            else:
                outputfile.write('u '+line+'\n')
        
        line = inputfile.readline()
        line = line.strip()

    inputfile.close()
    outputfile.close()
    return graph_count

def Q1():
    inputfileName = sys.argv[1]
    num_graphs1 = f(inputfileName,'input_gspan',1)
    num_graphs2 = f(inputfileName,'input_fsg',2)

    minSup = [0.05, 0.10, 0.25, 0.50, 0.95]
    runtime_gspan = []
    runtime_gaston = []
    runtime_fsg = []
    for i in minSup:
        srt = time.time()
        command =  './gSpan-64 -f input_gspan -s '+ str(i)+ ' -o'
        os.system(command)
        runtime_gspan.append(time.time()-srt)

    for i in minSup:
        srt = time.time()
        command =  './gaston '+str(num_graphs1*i)+' input_gspan input_gaston.fp'
        os.system(command)
        runtime_gaston.append(time.time()-srt)

    for i in minSup:
        srt = time.time()
        command =  './fsg -s '+str(i*100)+' input_fsg'
        os.system(command)
        runtime_fsg.append(time.time()-srt)

    print('runtime_gspan :',runtime_gspan)
    print('runtime_gaston :',runtime_gaston)
    print('runtime_fsg :',runtime_fsg)
    
    fig, ax = plt.subplots(figsize=(12, 6))
    X = [i*100 for i in minSup]
    plt.xticks(X)
    ax.set_xlabel("min support")
    ax.set_ylabel("time taken (in sec)")

    ax.plot(X, runtime_gspan, color='blue',label='gspan')
    ax.plot(X, runtime_gaston, color='red',label='gaston')
    ax.plot(X, runtime_fsg, color='green',label='fsg')
    ax.legend()

    fig.savefig('plot.png')



Q1()



