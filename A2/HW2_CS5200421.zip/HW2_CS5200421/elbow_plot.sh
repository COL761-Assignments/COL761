#!/bin/bash

# Check for correct number of arguments
if [ "$#" -ne 3 ]; then
    echo "Usage: sh elbow_plot.sh <dataset> <dimension> <output_file>"
    exit 1
fi

# Call the Python script
python3 elbow_plot.py $1 $2 $3
